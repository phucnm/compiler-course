# To test accept test, just `java Compiler accept_test.ul` as usual.
# To test reject tests in a quick way:
1. Compile RejectUnitTests.java, `make` should have done this.
2. Run `java RejectUnitTests reject*.ul`. Output should show `SUCCESS`.